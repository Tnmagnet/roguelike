All images drawn by Philipp Lenssen.

License:
http://creativecommons.org/licenses/by-nc/2.5/

For more info please see
http://blog.outer-court.com/archive/2006-08-08-n51.html