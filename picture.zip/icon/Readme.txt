420 RPG Icons - 34x34, .png format
By Henrique Lazarini (a.k.a.: Ails)